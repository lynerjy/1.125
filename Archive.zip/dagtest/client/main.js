import { Template } from 'meteor/templating';
import { ReactiveVar } from 'meteor/reactive-var';
import './main.html';

var g = new dagreD3.graphlib.Graph()
	.setGraph({})
	.setDefaultEdgeLabel(function () {
	  return {};
	});

// svg_edge_label = document.createElementNS('http://www.w3.org/2000/svg', 'text');
// edge_tspan = document.createElementNS('http://www.w3.org/2000/svg','tspan');
// edge_tspan.setAttributeNS('http://www.w3.org/XML/1998/namespace', 'xml:space', 'preserve');
// edge_tspan.setAttribute('dy', '1em');
// edge_tspan.setAttribute('x', '1');
// edge_link = document.createElementNS('http://www.w3.org/2000/svg', 'a');
// edge_link.setAttributeNS('http://www.w3.org/1999/xlink', 'xlink:href', 'http://google.com/');
// edge_link.setAttribute('target', '_blank');
// edge_link.textContent = 'IE Capable Edge link';
// edge_tspan.appendChild(edge_link);
// svg_edge_label.appendChild(edge_tspan);

nid = "n"+56;

g.setNode(0, {class: nid, shape: "house", labelType: 'html', label: "<a href=http://www.google.com>bla</a>"});
g.setNode(1, {label: "B"});
g.setNode(2, {shape: "house", label: "C"});
g.setNode(3, {label: "D"});

g.setEdge(0, 1, {class: "e1", label: "edge1"});
g.setEdge(0, 2, {class: "e2", label: "edge2"});

// g.setEdge(0, 1, {
//   style: "stroke-width: 4px; opacity:0.1;",
//   style: "stroke: #000"
// });

var svg = d3.select("svg")
  // Set up zoom support
  var zoom = d3.behavior.zoom().on("zoom", function() {
        inner.attr("transform", "translate(" + d3.event.translate + ")" +
                                    "scale(" + d3.event.scale + ")");
      });
  svg.call(zoom);



// console.log("g.edge:"+ g.edge);

var render = new dagreD3.render();


// Add our custom shape (a house)
render.shapes().house = function(parent, bbox, node) {
  var w = bbox.width,
      h = bbox.height,
      points = [
        { x:   0, y:        0 },
        { x:   w, y:        0 },
        { x:   w, y:       -h },
        { x: w/2, y: -h * 3/2 },
        { x:   0, y:       -h }
      ];
      shapeSvg = parent.insert("polygon", ":first-child")
        .attr("points", points.map(function(d) { return d.x + "," + d.y; }).join(" "))
        .attr("transform", "translate(" + (-w/2) + "," + (h * 3/4) + ")");

  node.intersect = function(point) {
    return dagreD3.intersect.polygon(node, points, point);
  };

  return shapeSvg;
};



var svg = d3.select("body").append("svg"),
    svgGroup = svg.append("g");
render(d3.select("svg g"), g);

  var svg = d3.select("svg");

g.nodes().forEach(function(v) {
  var node = g.node(v);
  // node.rx = node.ry = 5;
});

g.edges().forEach(function(e) {
  var edge = g.edge(e);
  console.log(edge);
  // edge.style("stroke-width",5);// node.rx = node.ry = 5;
  // can probably write in my own _onclick function for all edgepath this way.
  // find away to access .attr('stroke-width')

});


// RENDER A TOOL TIP

    inner = svg.append("g");

  // Simple function to style the tooltip for the given node.
var styleTooltip = function(name, description) {
  return "bla";
};

// Run the renderer. This is what draws the final graph.
render(inner, g);

inner.selectAll("g.node")
  .attr("title", function(v) { return styleTooltip(v, g.node(v).bamboo) })
  .each(function(v) { $(this).tipsy({ gravity: "w", opacity: 1 }); });

  svg.selectAll('g.edgePath').each(function() {
  console.log("d3thing"+d3.select(this).attr('id')); // Logs the id attribute.
});

// GET EDGE TOOLTIP TO WORK
inner.selectAll("g.edgePath")
  .attr("title", function(e) { return styleTooltip(e, g.edge(e).label) })
  .each(function(e) { $(this).tipsy({ gravity: "w", opacity: 0.5 }); });






// RESPOND TO CLICKS

  svg.selectAll("g.node").on("click", function(id) {
        var _node = g.node(id);
        // console.log("Clicked " + id,_node);
        // Session.set("lastnode",id);
        console.log("Node:" + id);
  });

  svg.selectAll("g.edgePath").on("click", function(id) {
    // var clickededge = this.childNodes[1].childNodes[0].getAttribute('id');
    console.log(this)
    console.log(this.childNodes[1].childNodes[0])
    var edgev = this.__data__.v;
    var edgew = this.__data__.w;
    console.log (edgev+ "going to"+ edgew);
    d3.selectAll("g.node."+nid)
        .style("opacity", "0.2");
    
});

//   Template.map.rendered = function(){
//   // Nodes.find().observe({
//   //   added: function (){
//   //   }
//   // });
// }


 
