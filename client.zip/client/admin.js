Template.AdminLayout.onCreated(function(){
  this.subscribe('comments');
});

Template.AdminLayout.events = ({

  'submit .contact': function(event,template){
  	event.preventDefault();
  	var cname = event.target.name.value;
  	var cemail = event.target.email.value;
  	var ccomment = document.getElementById('comments').value;
  	if (ccomment==''){
  		alert('Please leave a comment');
  		return
  	}

  	// if (Meteor.userId()){
   //  	var cid = Meteor.user().username;
   //  } else {
   //  	var cid = '';
   //  }
     if (Meteor.user()!=null){
	    var cid = Meteor.user().username;
	  } else {
	    var cid = Session.get('uip');
	  }

    var time = date.toString();

    // Update Comments
    var commentid = Comments.find().count() + 1; //* my comment ids count from 1 up
    Comments.insert({
        commentid: commentid,
        username: cid,
        time: time,
        name: cname,
        email: cemail,
        comment: ccomment
      });
    template.find(".contact").reset();
    document.getElementById('comments').value='';
    alert('Thank you!')

  }

 });
