

Template.maplist.helpers({

  maplist1: function(){
    return Maps.find({party:'democrat'});
  },

  maplist2: function(){
    return Maps.find({party:'republican'});
  },

  gotSignIn: function(){
    return true;
    // if (Meteor.userId()){
    //   return true;
    // }
    // return false;
  },

  ownAndEmpty: function(creator,mid){
    // if (Meteor.userId()){
    //   var cid = Meteor.user().username;
    // } else {var cid=''}
    if (Meteor.user()!=null){
      var cid = Meteor.user().username;
    } else {
      var cid = Session.get('uip');
    }

    if ((cid==creator || cid=='adminosaur') && Nodes.find({mapid:mid}).count()<=1){
      return true;
    } 
    return false;
  },

  thistr: function(mapid){
    var mid = Session.get('mapid');
    if (mid==mapid){
      return "#ddd";
    } return "";
  }

});

Template.maplist.events = ({

  'submit .map-entry': function(event,template){
    event.preventDefault();
    var party = event.target.mapdesc.id;
    var desc = event.target.mapdesc.value;
    var source = event.target.mapsource.value;
    if (desc==""){
      alert("Give a policy description");
     return;
    }
    if (desc.length>Session.get('charl')){
      alert("Enter less than "+Session.get('charl')+" characters")
      return;
    }
    if (source !='' && source.substring(0,7)!='http://'){
      if (source.substring(0,8)!='https://'){
      alert("Enter an source address beginning with http://")
      return;
    }
    }

    // var cid = Meteor.user().username;
    if (Meteor.user()!=null){
      var cid = Meteor.user().username;
    } else {
      var cid = Session.get('uip');
    }



    var time = date.toString();
    // var item = ClassData.findOne({owner: ipid});

    // Update Map
    if (Maps.find({}).count()==0){
      var mapid = 1;
    } else {
      var basemapnum = Maps.findOne({}, {sort: {mapid:-1}}).mapid;
    var mapid = basemapnum + 1; //* my map ids count from 1 up
    }
    
    Maps.insert({
        mapid: mapid,
        description: desc,
        party: party,
        numnodes: 1,
        creator: cid,
        creationtime: time
      });

    // Make Root Node
    if (Nodes.find({}).count() == 0){ // get the right id number for the first one
      var basenum = 1;
    } else {
      var basenum = Nodes.findOne({}, {sort: {nodeid:-1}}).nodeid;  
    }
    var nodeid = basenum + 1;
    Nodes.insert({
        nodeid: nodeid,
        description: desc,
        mapid: mapid,
        creator: cid,
        source: source,
        creationtime: time,
        root: true
      });

    Session.set("mapid",mapid);
    Session.set('lastnode',null);

    // Reset form
    template.find(".map-entry").reset();
    template.find("#r-form").reset();
    drawnewmap(mapid);

    // return false;
  },



  'click .map-button': function(){
    Session.set("notstarted",false);
    var lastmid = Session.get('mapid');
    var newmid = Session.set('mapid',this.mapid);
    if (lastmid != newmid){
      Session.set('lastnode',null);
      Session.set('genopen',false);
      Session.set('refnode',null);
    }

    // delete current map
    d3.select("g").remove(); // seems to be able to do without this?
    // removes everything, and my other one doesn't build a new map
    var svg = d3.select("svg"),
      inner = svg.append("g");

    // draw map of new id
    var mid = Session.get('mapid');
    currentPosition = [100,20];
    currentZoomScale = initialScale;
    drawnewmap(mid);
    

  },

  'click .map-del':function(){
    // Only allow if there's nothing left.

    var r = confirm("Are you sure you want to delete this policy?");
    if (r == true) {
    
    // Remove from nodes
    var nodeid = Nodes.findOne({mapid:this.mapid})._id;
    Nodes.remove(nodeid);

    // Remove from maps
    mapdbid = this._id;
    Maps.remove(mapdbid);

    // Change map viewed
    // delete current map
    d3.select("g").remove(); // seems to be able to do without this?
    // removes everything, and my other one doesn't build a new map
    var svg = d3.select("svg"),
    inner = svg.append("g");
    Session.set('mapid', 1);

    // draw new
    drawnewmap(mid);
  }
  return;
  }

});