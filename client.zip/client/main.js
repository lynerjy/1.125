import { Template } from 'meteor/templating';
import { ReactiveVar } from 'meteor/reactive-var';
import { Session } from 'meteor/session';
import { Accounts } from 'meteor/accounts-base';
// import '../imports/startup/accounts-config.js';
// import '../imports/ui/body.js';

// import './main.html';

Nodes = new Meteor.Collection("nodes");
Edges = new Meteor.Collection("edges");
Maps = new Meteor.Collection("maps");
Comments = new Meteor.Collection("comments");
// Users = new Meteor.Collection("musers");

Session.set("mapid",1);
Session.set("lastnode",null);
Session.set("uip",null);



date = new Date();


// Meteor.subscribe('nodes');
// Meteor.subscribe('edges');
// Meteor.subscribe('maps');
// Meteor.subscribe('musers');

Meteor.call(

  'getIP', function(error,result){
  if(error){
  }
  else {
    Session.set("uip",result);
  }
});



// Tracker.autorun(function(computation) {
// // 	    Accounts.ui.config({
// //     passwordSignupFields: "USERNAME_ONLY"
// // });

//   if (Meteor.userId()) {
// 	console.log('logged in')
// 	// delete current map
// 	d3.select("g").remove(); // seems to be able to do without this?
// 	// removes everything, and my other one doesn't build a new map
// 	var svg = d3.select("svg"),
// 	inner = svg.append("g");

//     // draw new
//     var mid = Session.get('mapid');
//     drawnewmap(mid);
//    } 
//    else if(!computation.firstRun){ // i.e. if it just logged out
//    		console.log('logged out')
// 	   	// delete current map
// 		d3.select("g").remove(); // seems to be able to do without this?
// 		// removes everything, and my other one doesn't build a new map
// 		var svg = d3.select("svg"),
// 		inner = svg.append("g");

// 		Session.set('refnode',null)
// 		Session.set('genopen',false)
// 		Session.set("editing",false); // as in currently editing (i.e. edit pane should appear)
// 		Session.set('deleting', false);

// 	    // draw new
// 	    var mid = Session.get('mapid');
// 	    drawnewmap(mid);


//   }
// });



Template.OverallLayout.events({

  'click .title-link': function(){
      Session.set("notstarted",true);
    }

});

Accounts.ui.config({
	passwordSignupFields: "USERNAME_ONLY"
});










