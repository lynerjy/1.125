
Session.set('refnode',null)
Session.set('genopen',false)
Session.set("editing",false); // as in currently editing (i.e. edit pane should appear)
Session.set('deleting', false);


// MAP VISUAL PROPERTIES
// var dirf = 0.2; // originally, how much to dim/brighten the direct node by
var oop = 0.5; // original opacity (of the css node .rect value)
var causeprompt = "Will lead to...";
var signinprompt = "Sign in to contribute"
var dpols = ['policy 1','policy 2','policy 3','policy 4', 'policy 5'];
var rpols = ['policy 1','policy 2','policy 3','policy 4', 'policy 5'];
var demcolor ='#5A79A5';
var repcolor = '#ce0000';
nodewidth = 25; // width of text in node for word wrap)
charl = 200; // default character limit
charm = 10; // character minimum
dashthis = null;
mid = 1;
initialScale = 0.75
currentZoomScale = initialScale;
currentPosition = [100,20];

// MAP COPY
upvote = "upvote";
downvote = "downvote";




// Draw SVG map
drawnewmap = function(mid){

  console.log('drawing')

    // Initialize new graph
  g = new dagreD3.graphlib.Graph()
    .setGraph({
      rankdir: "TB"
    })
    .setDefaultEdgeLabel(function () {
    return {};
  });

  // Populate nodes/edges for graph depending on mode (whether full map/individuals)
  populateg(g);

  // Set graph zoom/scale properties
  var svg = d3.select("svg"),
      inner = svg.select("g");

  // Set up tool tip
  var styleTooltip = function(name, description) {
    return description;
  };

  var zoom = d3.behavior.zoom()
    .scale(currentZoomScale)
    .on("zoom", function() {
          inner.attr("transform", "translate(" + currentPosition + ")" + "scale(" + currentZoomScale + ")");
          currentZoomScale = d3.event.scale;
          currentPosition = d3.event.translate;
        });
  svg.call(zoom);

  // Create renderer (with arrow modification)
  var render = new dagreD3.render();
  
  // Add our custom arrow. MAYBE MOVE TO ANOTHER SCRIPT?
  render.arrows().hollowPoint = function normal(parent, id, edge, type) {
    var marker = parent.append("marker")
      .attr("id", id)
      .attr("viewBox", "0 0 20 20")
      .attr("refX", 8)
      .attr("refY", 5)
      .attr("markerUnits", "strokeWidth")
      .attr("markerWidth", 8)
      .attr("markerHeight", 6)
      .attr("orient", "auto");

    var path = marker.append("path")
      .attr("d", "M 0 0 L 10 5 L 0 10 z")
      .style("stroke-width", 1)
      .style("stroke-dasharray", "1,0")
      .style("fill", "#000")
      .style("stroke", "#000");
    dagreD3.util.applyStyle(path, edge[type + "Style"]);
  };
  render(inner, g); 


    // Node Tooltip
    if (Session.get('genopen')==false && (Session.get('editing')==false) && Session.get('deleting')==false){
      // if (Meteor.user()!=null){
        inner.selectAll("g.node")
          .attr("title", function(v) { return styleTooltip(v, causeprompt) })
          .each(function(v) { $(this).tipsy({ gravity: "w", className:'addnode'}); });    
      // }
      // else {
      //   inner.selectAll("g.node, g.edgeLabel")
      //     .attr("title", function(v) { return styleTooltip(v, signinprompt) })
      //     .each(function(v) { $(this).tipsy({ gravity: "w", className:'signintip'}); });  
      // }
    }


  // Center graph
  var width = document.getElementById('mapspace').offsetWidth;
  zoom
    .translate(currentPosition)
    .scale(currentZoomScale)
    .event(svg);
  

  checknodes(); 
  
  // lastmid = mid;

}


// Populate which nodes/edges for map
function populateg(g){ // i'm working on mode iconsistently. half decided outside this code, half in
  
  if (Meteor.user()!=null){
    var cid = Meteor.user().username;
  } else {
    var cid = Session.get('uip');
  }

  // 2. CONFIGURE EDGES
    // Count all likelys/unlikelys across all maps and edges
    var totalvotes = 0;
    Edges.find({}).forEach(function (e){
      totalvotes = totalvotes + e.likelys.length + e.unlikelys.length;
    });

    // Build edges with appropriate label
    Edges.find({mapid: mid}).forEach(function (e) {

      // Initialize visual properties
      var preb1 = "<table class='fakebars'><tr class='fakebars'><td class='fakebars'>Likely:</td><td class='fakebars'><p style='width:";
      var midb = "px' class='bar1'>.</p></td></tr><tr class='fakebars'><td class='fakebars'>Unlikely:</td><td class='fakebars'><p style='width:";
      var postb2 = "px' class='bar2'>.</p></td></tr></table>";
      var es1= "<br><select id='";
      var es2 = "' onchange='edgechange(this)'><option style='color:gray' value='null'>Select likelihood...</option><option value='2' "
      var elikely = "";
      var es3 = ">Likely</option><option value='1'";
      var eunlikely = "";
      var es4 = ">Unlikely</option></optgroup></select>";

      //get likely/unlikely counts for this edge
      var likelyc = e.likelys.length;
      var unlikelyc = e.unlikelys.length;
      // barlength should be function of all votes casted
      var b1len = 2 + Math.round(likelyc/totalvotes*98); // likely bar length, in pixels. 2 px is base length when 0 votes
      var b2len = 2 + Math.round(unlikelyc/totalvotes*98); // unlikely bar length

      // change edge opacity based on likely average
      var eopnum = 0.1 + likelyc/(likelyc + unlikelyc)*0.9;
      var eopacity = String(eopnum);
      if ((likelyc+unlikelyc)==0){
        eopacity = 0.5;
      }
      // change the opacity of the linked node accordingly
      var nodeid = Nodes.findOne({nodeid:e.target})._id;
      Nodes.update(nodeid, {$set: {opacity: eopacity}});
      
      // opacity shouldn't be a database value anymore

      // change pre-selection based on this cid's status
      if (e.likelys.includes(cid)){
        elikely = "selected";
      } else if (e.unlikelys.includes(cid)){
        eunlikely = "selected";
      }

      var eselect = es1+e.edgeid+es2+elikely+es3+eunlikely+es4;


      // if (Meteor.user()!=null){
        elabel = preb1+b1len+midb+b2len+postb2+eselect;
      // }
      // else {
      //   elabel = preb1+b1len+midb+b2len+postb2;
      // }

      // Set edges
      g.setEdge(e.source, e.target, {
        class: "e-"+e.edgeid,
        lineTension: .8,
        lineInterpolate: "linear",
        labelType: 'html',
        label: elabel, 
        labelStyle: "color: #888", // PROBLEM! including opacity here makes the stars all draw haywire. so weird.
        style: "stroke: #000; opacity:"+eopacity,
        vote: e.votestatus,
        arrowhead: "hollowPoint"
      }); 
    }); 



    // 1. CONFIGURE NODES
    // Change node variables depending on mode
    var nl0 = "<table class='nodetable'><tr><td colspan='3' class='ndesc'>"; // Row 1b/2a: Pre-description
    var nl2b = "</td></tr><tr>"; // Row 2b: Post-description
    // Row 3a: Edit buttons (toggled below, as need to reset with every n)
    // Row 3b/4a: post-description, pre username row
    var nl4 = "</td></tr></table>"; // Row 4b: post username


    // Build the nodes with appropriate label
    Nodes.find({mapid: mid}).forEach(function (n) {
      var nl3a = ""; // Row 1: Edit buttons (optional)
      var nl3s = "";
      // If editing (whether global/loose/own)...
      if (n.source!='' && n.source!=undefined){
        nl3s ="<td colspan = '3' class='nsource'><a href='"+n.source+"'>Source</a></td></tr><tr>";
      }
      if((cid==n.creator || cid=='adminosaur') && Edges.find({source:n.nodeid}).count()==0){ // Check if there're any attached to it. universal admin access hooray!
        // nl1b = ""; //empty the add buttonbutton.. really?
        nl3a = "<td><i><a title='edit' class='ebutton'>&#9998</a></td><td><a title='delete' class='dbutton'>&#10007;</a></i></td>";
      }
      // var nl3b = "<td class='nuser'>Created by: "+n.creator; 
      var nl3b = '<td>';

      // var fillcolor =''
      // if (n.creator=='adminosaur'){
      //   var fillcolor = '#d5b77a';
      //   nl3b = "<td class='nuser'>Source: "+n.source;
      // }

      g.setNode(n.nodeid, {
        labelType: 'html',
        label: nl0+n.description+nl2b+nl3s+nl3a+nl3b+nl4,
        // label: desc,
        style: "opacity:"+n.opacity,
        // labelStyle: "color: #ea4235; opacity:0.5",
        // labelStyle: "opacity:"+n.opacity, // this weirdly moves the labels to totally the wrong place
        rx: 5,
        ry: 5,
        padding: 0
      });
    });


    // Re-colour the root node
    Nodes.find({mapid: mid, root: true}).forEach(function(m){
      if (Maps.findOne({mapid:mid}).party=='democrat'){
        var rootc = demcolor;
      } else {
        var rootc = repcolor;}

        //label vars
      var nl3s = "";
      // If editing (whether global/loose/own)...
      if (m.source!='' && m.source!=undefined){
        nl3s ="<td colspan = '3' class='nsource'><a href='"+m.source+"'>Source</a></td></tr><tr>";
      }
      // var nl3b = "<td class='nuser'>Created by: "+m.creator; 
      var nl3b = '<td>';

      // var desc = wordwrap(m.description,nodewidth);
      g.setNode(m.nodeid,{
        labelType: 'html',
        label: nl0+m.description+nl2b+nl3s+nl3b+nl4,
        style: "fill:"+rootc,
        // style: "fill: #cc3333",
        rx: 5,
        ry: 5,
        padding: 0
      });
    });

    
  
  }

// Triggered on new edge likelihood selection
edgechange = function(a){ // a is the select object
  var edgeid = Edges.findOne({edgeid:Number(a.id)})._id;
  var lvalue = Number(a.options[a.selectedIndex].value); // selected value: 2 - likely, 1 - unlikely, null - no selection
  // var cid = Meteor.user().username;

  if (Meteor.user()!=null){
    var cid = Meteor.user().username;
  } else {
    var cid = Session.get('uip');
  }


  // Update edge
  if (lvalue == 1){
    Edges.update(edgeid, {$push: {unlikelys: cid}});
    Edges.update(edgeid, {$pull: {likelys: cid}});
  } else if(lvalue == 2){
    Edges.update(edgeid, {$push: {likelys: cid}});
    Edges.update(edgeid, {$pull: {unlikelys: cid}});
  } else if(isNaN(lvalue)){
    Edges.update(edgeid, {$pull: {likelys: cid}});
    Edges.update(edgeid, {$pull: {unlikelys: cid}});
  }

  $(".tipsy").remove();

  // redrawmap, with new edge label lengths, and new edge opacity


}


// Check for clicks on nodes
checknodes = function(){
  
  // if (Meteor.user() ==null){
  //   return;
  // }

  var svg = d3.select("svg");

  // Check for node click -- to find a target
  svg.selectAll("g.node").on("click", function(id) {
    if (Session.get('genopen')==false && Session.get('editing')==false && Session.get('deleting')==false){
      var nodeid = Number(g.node(id));
      Session.set("lastnode",id);
      Session.set('refnode',Session.get('lastnode'));  // take last node as the place holder
      Session.set('lastnode') == null; // Emptying out lastnode so it doesn't pre-show as the "last text"
    }

    // change to dash on clicked
    //Session.get('lastnode')==null && 
      var nodeid = Number(g.node(id));
      // this.setAttribute('style','stroke-dasharray:5');
      if (Session.get('refnode')!=null){
        // console.log('where my dash')
        // CHANGE THIS TO CHANGE SAME WAY STAR CHANGES
        dashthis = this;
      }
      Session.set("lastnode",id);
  
  });
    // var width = document.getElementById('mapspace').offsetWidth;
    // No clue why this is working, but at this point I don't care
    if (dashthis!=null){
      dashthis.childNodes[0].setAttribute('style','stroke-dasharray:5');
    }

}

// Wraps text to reduce node size (https://gist.github.com/mmcgrath/8783910)
function wordwrap( str, width) {
  var brk = '<br>';
  var cut = false;
  width = width || 75;

  if (!str) { 
    return str; }
  var regex = '.{1,' +width+ '}(\\s|$)' + (cut ? '|.{' +width+ '}|.+$' : '|\\S+?(\\s|$)');
  return str.match( RegExp(regex, 'g') ).join( brk );
}



Template.map.helpers({

  drawmap: function(){
    mid = Session.get('mapid');
    drawnewmap(mid);
  }

});


Template.MapLayout.onCreated(function(){
  this.subscribe('nodes');
  this.subscribe('edges');
  this.subscribe('maps');
  // this.subscribe('comments');
});


Template.MapLayout.helpers({

  starterbuild: function(){
        // Starting the different maps for experimentation
    if (Maps.find({}).count() == 0){ // i.e. if i'm starting map anew. this is so stupid.

      // Maps.insert
      // Democrat policies
      for (i = 1; i <= dpols.length; i++) {
        Maps.insert({ mapid: i, description: dpols[i-1],party:'democrat', numnodes: 0});

        // Make Root Node
        if (Nodes.find({}).count() == 0){ var basenum = 1;} 
        else { var basenum = Nodes.findOne({}, {sort: {nodeid:-1}}).nodeid;}
        var nodeid = basenum + 1; // get the right unique node id number
        Nodes.insert({class: nodeid,nodeid: nodeid,description: dpols[i-1],mapid: i, root: true});
      }
      
      // Repuplican policies
      for (i = (1+dpols.length); i <= (dpols.length+rpols.length); i++) {
        Maps.insert({ mapid: i, description: rpols[i-dpols.length-1], party: 'republican',numnodes: 0});

        // Make Root Node
        if (Nodes.find({}).count() == 0){ var basenum = 1;} 
        else { var basenum = Nodes.findOne({}, {sort: {nodeid:-1}}).nodeid;}
        var nodeid = basenum + 1; // get the right unique node id number
        Nodes.insert({class: nodeid,nodeid: nodeid,description: rpols[i-dpols.length-1],mapid: i,root: true});  
      }
      Session.set("mapid",1);
      Session.set('lastnode',null);
    }

  },

    notChrome:function(){
     if(BrowserDetect.browser != "Chrome"){
      return true;
     }
     return false;
  },

  lastclicked: function(){
    if (Session.get('refnode')==null || Session.get('editing')==true || Session.get('deleting')==true){ //if an add wasn't clicked and if editing's not opened..
      return false;
    } else {
      $(".tipsy").remove();
      Session.set('genopen',true);
      Session.set('lastnode',null); // so that lasttext starts empty
      return true;
    }
  },

  editing: function(){
    if (Session.get('editing')==true && Session.get('genopen')==false){
      Session.set('refnode',Session.get('lastnode'));
            $(".tipsy").remove();

      return true;
    }
    else {
      return false;
    }
  }

});


Template.gennode.helpers({

  reftext: function(){
    var lastid = Number(Session.get('refnode')); // hm interesting
    var nodedesc = Nodes.findOne({nodeid:lastid}).description;
    return nodedesc;
  },

  lasttextclicked: function(){
    if (Session.get('lastnode')!=null){
      return true
    }
  },

  lasttext: function(){
      var lastid = Number(Session.get('lastnode')); // hm interesting
      var nodedesc = Nodes.findOne({nodeid:lastid}).description;
      return nodedesc;

  }

});


Template.gennode.events = ({

  // Add a new node to database
  'submit form': function(event, template){
    event.preventDefault();

    var parentid = Number(Session.get("refnode"));
    var nodeid = Nodes.findOne({}, {sort: {nodeid:-1}}).nodeid + 1; // Node id starts at 1. 
    var edgeid = Edges.find().count() + 1;
    var mapid = Session.get("mapid");
    // var cid = Meteor.user().username;
    var time = date.toString();

    if (Meteor.user()!=null){
      var cid = Meteor.user().username;
    } else {
      var cid = Session.get('uip');
    }


      // Writing own node
      var longdesc = template.find(".nodedesc1").value;
      if (longdesc==""){
        alert("fill in all fields");
        return;
      }
      if (longdesc.length>charl || longdesc.length<charm){
        alert("Enter less than "+charl+" and more than "+charm+" characters")
        return;
      }

      var source = template.find(".nodedesc2").value;
      if (source !='' &&  source.substring(0,7)!='http://'){
        if (source.substring(0,8)!='https://'){
        alert("Enter an address beginning with http://")
        return
      }
      }
    // Update nodes
    Nodes.insert({
      nodeid: nodeid, // but should be an increment of whatever number it's up to in that parent map
      description: longdesc, // store it as long
      mapid: mapid,
      creator: cid,
      creationtime: time,
      source: source,
      parent: parentid
      });

    

    // Update edges
    Edges.insert({
      // note that the source target terminology is a bit mixed mixed
      edgeid: edgeid,
      target: nodeid, // where parentid/target is what the node points to
      source: parentid,
      mapid: mapid,
      likelys: [],
      unlikelys: [],
      votestatus: upvote,
      opacity: oop
    });

    // Update number of nodes in map
    var thismapid = Maps.findOne({mapid:mapid})._id;
    var newnum = Nodes.find({mapid:mapid}).count();
    Maps.update(thismapid, {$set: {numnodes: newnum}});

    // Reset form
    template.find(".node-entry").reset();
    Session.set('lastnode',null);
    Session.set('refnode',null);
    Session.set('genopen',false);
    dashthis=null;
    return false;
    },


  'click .closegen-button': function(){
    var mid = Session.get('mapid');
    drawnewmap(mid);
    dashthis = null;
    Session.set('lastnode',null);
    Session.set('genopen',false);
    Session.set('refnode',null);

  }

});


Template.map.events({

  // I SHOULD REAlly find a way to find the host node id here. Instead of depending on lastnode.
  // 'click .addbutton': function(){
  //   console.log('add clicked for'+Session.get('lastnode'))
  //   if (Session.get('genopen')==false && Session.get('editing')==false){
  //     Session.set('refnode',Session.get('lastnode'));  // take last node as the place holder
  //     Session.set('lastnode') == null; // Emptying out lastnode so it doesn't pre-show as the "last text"
  //   }
  // },

  'click .ebutton': function(){
    if (Session.get('genopen')==false){
      Session.set('editing',true);
      var lastid = Number(Session.get('lastnode'));  
      Session.set('refnode',null);
    }
  },

  'click .dbutton': function(){
    if (Session.get('genopen')==true){
      return;
    }
    Session.set('deleting',true); // placeholder just to say that gennode shouldn't open
    var mid = Session.get('mapid');
    var pid = Number(Session.get('refnode'));
    var thisid = Nodes.findOne({nodeid:pid})._id;
    var r = confirm("Are you sure you want to delete this scenario?");
    if (r == true) {
      deletechildren(pid);
      function deletechildren(pid){
        Edges.find({source:pid}).forEach(function(e){
          var nodenum = e.target;
          var nid = Nodes.findOne({nodeid:nodenum})._id;
          Edges.find({target:nodenum}).forEach(function(j){
            Edges.remove(j._id);
          });
          Nodes.remove(nid);
          deletechildren(nodenum);
        });
      }
      Nodes.remove(thisid);
      //change numnodes
      var thismapid = Maps.findOne({mapid:mid})._id;
      var newnum = Nodes.find({mapid:mid}).count();
      Maps.update(thismapid, {$set: {numnodes: newnum}});
      //remove edge
      Edges.find({target:pid}).forEach(function(k){
        Edges.remove(k._id);
      })
    $(".tipsy").remove();
    drawnewmap(Session.get('mapid'));
    }
    Session.set('refnode',null)
    Session.set('deleting',false);
    dashthis = null;

  },

  'click .nfav':function(){
    if (Session.get('genopen')==true){
      return;
    }
    Session.set('deleting',true); // placeholder just to say that gennode shouldn't open
        Session.set('refnode',null)

    Session.set('deleting',false);

  }

  // PROBABLY HAVE TO PREVENT DEFAULT FOR EVERYTHING, which is why it keeps redrawing

});

Template.editpane.events({


  // EDITPANE SHOULD HAVE DROP DOWN ALSOOOooo
  // What should I do with these taggsssss




  'click .closegen-button': function(){
    var mid = Session.get('mapid');
    drawnewmap(mid);
    dashthis = null;

    Session.set('lastnode',null);
    Session.set('editing',false);
    Session.set('refnode',null);
  },

 'submit form': function(event, template){
    event.preventDefault();

    // Get the edit
    var longdesc = template.find(".nodedesc2").value;
    if (longdesc==""){
      alert("cannot submit empty field");
      return;
    }
    if (longdesc.length>Session.get('charl')){
      alert("Enter less than "+Session.get('charl')+" characters")
      return;
    }

    // get the source edit
    var newsource = template.find(".nodedesc3").value;
    if (newsource !='' &&  newsource.substring(0,7)!='http://'){
      if (newsource.substring(0,8)!='https://'){
        alert("Enter an address beginning with http://")
        return
      }
    }

    // PUT IT BACK WHERE IT BELONGSssSSSSsSS
    var lastid = Number(Session.get('lastnode'));
    var thisid = Nodes.findOne({nodeid:lastid})._id;
    Nodes.update(thisid, {$set: {description:longdesc}});
    Nodes.update(thisid, {$set: {source:newsource}});

    // Reset form
    template.find(".node-edit").reset();
    Session.set('lastnode',null);
    Session.set('editing',false);
    Session.set('refnode',null);
    dashthis = null;
    return false;
    }

});

Template.editpane.helpers({

  lasttext: function(){
    var lastid = Number(Session.get('refnode')); // hm interesting
    var nodedesc = Nodes.findOne({nodeid:lastid}).description;
    return nodedesc;
  },

  lastsource: function(){
    var lastid = Number(Session.get('refnode')); // hm interesting
    var nodesource = Nodes.findOne({nodeid:lastid}).source;
    return nodesource;
  }

});


